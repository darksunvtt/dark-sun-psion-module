Hooks.once('ready', async () => {
  console.log('Dark Sun Psion Module | Initializing (v12 compatibility)...');
  for ( const pack of game.packs.filter(p => p.metadata.name.startsWith('psion-')) ) {
    await pack.getIndex();
  }
  if (game.system.id === 'dnd5e') {
    CONFIG.DND5E.classFeatures = CONFIG.DND5E.classFeatures || {};
    CONFIG.DND5E.classFeatures['psion'] = {
      name: 'Psion',
      label: 'Psion',
      img: 'icons/magic/mind/brain-blue.webp'
    };
  }
});